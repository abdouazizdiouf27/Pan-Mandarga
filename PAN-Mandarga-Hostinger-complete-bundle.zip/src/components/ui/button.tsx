import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  // Base: premium feel — uppercase tracking on premium variants, smooth transition, subtle lift on hover
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-all duration-200 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-background aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive active:translate-y-0 hover:-translate-y-0.5",
  {
    variants: {
      variant: {
        // Primary — fond foncé / texte clair (foreground on background)
        default:
          "bg-primary text-primary-foreground shadow-premium-sm hover:bg-primary/90 hover:shadow-premium-md",
        destructive:
          "bg-destructive text-white shadow-premium-sm hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
        // Outline — bordure fine, hover inverse
        outline:
          "border border-border bg-transparent text-foreground shadow-xs hover:bg-foreground hover:text-background dark:border-input dark:hover:bg-input/50",
        // Accent — doré sablé
        accent:
          "bg-accent text-accent-foreground shadow-premium-sm hover:bg-accent-deep",
        // Secondary — fond surface
        secondary:
          "bg-secondary text-secondary-foreground shadow-xs hover:bg-secondary/80",
        ghost:
          "hover:bg-muted hover:text-foreground dark:hover:bg-muted/50",
        link: "text-primary underline-offset-4 hover:underline hover:-translate-y-0",
      },
      size: {
        default: "h-11 px-5 text-sm has-[>svg]:px-4.5",
        sm: "h-9 px-4 text-xs gap-1.5 has-[>svg]:px-3",
        lg: "h-12 px-8 text-sm has-[>svg]:px-6",
        xl: "h-14 px-10 text-sm has-[>svg]:px-7",
        icon: "size-11",
        "icon-sm": "size-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: React.ComponentProps<"button"> &
  VariantProps<typeof buttonVariants> & {
    asChild?: boolean
  }) {
  const Comp = asChild ? Slot : "button"

  return (
    <Comp
      data-slot="button"
      className={cn(buttonVariants({ variant, size, className }))}
      {...props}
    />
  )
}

export { Button, buttonVariants }
